#!/usr/bin/env python

WP_LOC = dict()

WP_LOC[0] = (43.872936, -112.725333)
WP_LOC[1] = (43.873419, -112.725317)
