#!/usr/bin/env python

WP_LOC = dict()

WP_LOC[0] = (43.874044, -112.728703)
WP_LOC[1] = (43.874044, -112.729403)
