#!/usr/bin/env python

WP_LOC = dict()

WP_LOC[0] = (43.872903, -112.729719)
WP_LOC[1] = (43.872892, -112.729172)
