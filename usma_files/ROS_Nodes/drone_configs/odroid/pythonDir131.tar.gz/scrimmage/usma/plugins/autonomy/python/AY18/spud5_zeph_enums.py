#!/usr/bin/env python

WP_LOC = dict()

WP_LOC[0] = (43.871483, -112.726658)
WP_LOC[1] = (43.871094, -112.726647)
