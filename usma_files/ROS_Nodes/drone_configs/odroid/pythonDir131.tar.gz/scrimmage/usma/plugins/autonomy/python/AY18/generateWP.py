#Creates a list of waypoints that form a box
#Needs the northwest-most point and southeast-most point to generate the rest of the waypoints within the box
#Creates the waypoints based off of how many waypoints you want to generate
#
# Sam Galbreath
# USMA
# 31 Mar 2018

import numpy as np
import math

northwest = (43.876769, -112.732598)
southeast = (43.867794, -112.720137)
num_of_lats = 4 #actual number minus 1 here because end point included later
num_of_lons = 4 #actual number minus 1 here because end point included later
num_of_points = (num_of_lats + 1)*(num_of_lons + 1)

dy = abs(float((northwest[0] - southeast[0])/num_of_lats)) #divide dy and dx by the number of points you want in each direction
dx = abs(float((northwest[1] - southeast[1])/num_of_lons))

up_down = np.arange(southeast[0],northwest[0],dy) #only works as arange(small,big,step)
up_down = np.append(up_down,northwest[0]) #add northern-most point to end of array
left_right = np.arange(northwest[1], southeast[1],dx)
left_right = np.append(left_right,southeast[1]) #add eastern-most point to end of array

print("Total number of waypoints generated: " + repr(num_of_points))
print("Approximate step size for latitude: " + repr(dy*110306.407) + " [m]") #rough approx on dist
print("Approximate step size for longitude: " + repr(dx*79447.877) + " [m]") #rough approx on dist

n = 0

for i in range(0, num_of_lats + 1):
    for j in range(0, num_of_lons + 1):
        wp_array = (up_down[i],left_right[j])
        print("WP_LOC[" + repr(n) + "] = " + repr(wp_array))
        n = n + 1
