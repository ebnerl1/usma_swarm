with open('radfile.csv', 'r') as radfile:
    radreader = csv.reader(radfile)
    for row in radreader:
        counts = int(row[0])
        radtype = row[1]
    
lat = pos.lat
lon = pos.lon
alt = pos.alt
counts, radtype = getcounts()
print(counts)
print(radtype)


