#!/usr/bin/env python

WP_LOC = dict()

#Range 11 points

WP_LOC[0] = ( 41.359092, -74.031663 )
WP_LOC[1] = ( 41.357422, -74.031588 )
