import numpy as np
import math
import autopilot_bridge.msg as apbrg
import ap_msgs.msg as apmsg
from autopilot_bridge.msg import LLA
import ap_lib.gps_utils as gps
import ap_lib.ap_enumerations as enums
import ap_lib.sasc_scrimmage as ss
import usma_enumerations as usma_enums
import timeit
import socket
import sys

finishedList = []

class Fly(ss.Tactic):

    global finishedList 
    def separatePoints(starting, ending, num_of_points):
        #print(starting)
        #print(ending)
        #print(num_of_points)
        iterable_wp = [starting]
        inc_lon = (ending[0] - starting[0])/(num_of_points-1)
        inc_lat = (ending[1] - starting[1])/(num_of_points-1)
        stored_pt = (starting[0]+inc_lon,starting[1]+inc_lat)
        for i in range(1,num_of_points):
            iterable_wp.append(stored_pt)
            stored_pt = (stored_pt[0]+inc_lon, stored_pt[1]+inc_lat)
        return (iterable_wp)

    def init(self, params):
        self._id = int(params['id'])
        self._file_id = params['id']
        self._target_id = -1
        self._wp = np.array([0, 0, 0])
        self._max_range = enums.MAX_RANGE_DEF
        self._fov_width = enums.HFOV_DEF
        self._fov_height = enums.VFOV_DEF
        self._own_pose = apbrg.Geodometry()
        self._blues = dict()
        self._safe_waypoint = np.array([0, 0, 0])
        self._last_ap_wp = np.array([0, 0, 0])
        self._action = ["None", 0]
        self._vehicle_type = int(params['vehicle_type'])
        self._name = 'Fly'
        #self._location = int(params['location'])
        #self._desired_lat = float(usma_enums.WP_LOC[self._location][0])
        #self._desired_lon = float(usma_enums.WP_LOC[self._location][1])

        # Initialize Variables for Waypoint Assignment
        self._subswarm_id = 0
        self._id_in_subswarm = []
        self._first_tick = True
        self._subswarm_num_to_assign = []
        self._subswarm_wp_assignment = dict()
        self._wp_assigned = []
        for i in range(0, len(usma_enums.WP_LOC)):
            self._wp_assigned.append(False)  

        # Initialize Variables for Sequencing between Waypoints
        self._wp_id_list = []   # List of WPs to be assigned to this UAS
        for i in range(0, len(usma_enums.WP_LOC)):
            self._wp_id_list.append(i)  # Place holder for other logic
        self._wp_id_list_id = 0     # Index within assigned list of WPs
        self._loc = self._wp_id_list[self._wp_id_list_id]
        self._desired_lat = float(usma_enums.WP_LOC[self._loc][0])
        self._desired_lon = float(usma_enums.WP_LOC[self._loc][1])
        #finishedList = []
        self._time_at_wp = 0
        self._time_start = 0
        self._at_wp = False      
        
    def step_autonomy(self, t, dt):
        # Go to desired latitude, longitude, and maintain altitude
        # deconfliction:
        self._wp = np.array([self._desired_lat, self._desired_lon, 
                             self._last_ap_wp[2]])

        pos = self._own_pose.pose.pose.position

        dist = gps.gps_distance(pos.lat, pos.lon, self._desired_lat, self._desired_lon)

        if self._first_tick == True:
            blue_in_subswarm = dict()
            i = 0

            # Determine your own subswarm ID
               #key     #value
            for blue_id, blue in self._blues.iteritems():
                if blue.vehicle_id == self._id:
                    self._subswarm_id = blue.subswarm_id
                    break
 
            print "SS_ID: ", self._subswarm_id
            print pos
           
            # Build a list of all vehicle IDs within your subswarm

            for blue_id, blue in self._blues.iteritems():
                if blue.subswarm_id == self._subswarm_id:
                    self._id_in_subswarm.append(blue.vehicle_id)
                    self._subswarm_num_to_assign.append(0) 
                    blue_in_subswarm[i] = blue
                    i = i+1        
            print "IDs in Subswarm: ", self._id_in_subswarm
            
            #for i in usma_enums.WP_LOC:
            #    finishedList.append(False)
            #print finishedList
            
    
            

            self._first_tick = False

        return True
