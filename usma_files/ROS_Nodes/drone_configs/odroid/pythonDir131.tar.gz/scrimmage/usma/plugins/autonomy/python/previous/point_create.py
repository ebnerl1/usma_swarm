def separatePoints(starting, ending, num_of_points):
    #print(starting)
    #print(ending)
    #print(num_of_points)
    iterable_wp = dict()
    iterable_wp[0] = starting
    inc_lon = (ending[0] - starting[0])/(num_of_points-1)
    inc_lat = (ending[1] - starting[1])/(num_of_points-1)
    stored_pt = (starting[0]+inc_lon,starting[1]+inc_lat)
    for i in range(1,num_of_points):
        iterable_wp[i] = (stored_pt)
        stored_pt = (stored_pt[0]+inc_lon, stored_pt[1]+inc_lat)
    return (iterable_wp)
        #RC_LOC[0] = ( 41.391865, -73.952959 )
        #RC_LOC[15] = ( 41.391241, -73.952860 )

sum_list = separatePoints(( 41.359318, -74.032264 ), ( 41.356857, -74.030953 ), 25)
counter = 0
for i in sum_list:
 # print(counter)
  print(sum_list[i])
  counter+=1


